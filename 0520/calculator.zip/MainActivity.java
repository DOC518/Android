package com.example.calculator;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private TextView textViewResult;
    private LinearLayout historyLayout;
    private double firstNumber = 0;
    private double secondNumber = 0;
    private String currentOperation = "";
    private boolean isFirstNumber = true;
    private StringBuilder currentInput = new StringBuilder();
    private List<String> history = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textViewResult = findViewById(R.id.textViewResult);
        historyLayout = findViewById(R.id.historyLayout);

        setNumberButtonListeners();
        setOperationButtonListeners();
        setHistoryButtonListener();
    }

    private void setNumberButtonListeners() {
        int[] numberButtonIds = {
                R.id.button0, R.id.button1, R.id.button2, R.id.button3,
                R.id.button4, R.id.button5, R.id.button6, R.id.button7,
                R.id.button8, R.id.button9
        };

        View.OnClickListener numberButtonClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Button button = (Button) v;
                currentInput.append(button.getText().toString());
                textViewResult.setText(currentInput.toString());
            }
        };

        for (int id : numberButtonIds) {
            findViewById(id).setOnClickListener(numberButtonClickListener);
        }
    }

    private void setOperationButtonListeners() {
        int[] operationButtonIds = {
                R.id.buttonDivide, R.id.buttonMultiply, R.id.buttonSubtract,
                R.id.buttonAdd, R.id.buttonEquals, R.id.buttonClear,
                R.id.buttonBackspace, R.id.buttonDot
        };

        View.OnClickListener operationButtonClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Button button = (Button) v;
                String operation = button.getText().toString();

                switch (operation) {
                    case "C":
                        currentInput.setLength(0);
                        firstNumber = 0;
                        secondNumber = 0;
                        currentOperation = "";
                        isFirstNumber = true;
                        textViewResult.setText("0");
                        break;
                    case "⌫":
                        if (currentInput.length() > 0) {
                            currentInput.setLength(currentInput.length() - 1);
                            textViewResult.setText(currentInput.length() == 0 ? "0" : currentInput.toString());
                        }
                        break;
                    case ".":
                        if (!currentInput.toString().contains(".")) {
                            currentInput.append(".");
                            textViewResult.setText(currentInput.toString());
                        }
                        break;
                    case "=":
                        if (!currentOperation.isEmpty() && currentInput.length() > 0) {
                            secondNumber = Double.parseDouble(currentInput.toString());
                            int result = (int) performOperation(firstNumber, secondNumber, currentOperation);
                            String resultStr = String.valueOf(result);
                            textViewResult.setText(resultStr);
                            history.add(firstNumber + " " + currentOperation + " " + secondNumber + " = " + resultStr);
                            currentInput.setLength(0);
                            currentInput.append(resultStr);
                            firstNumber = result;
                            currentOperation = "";
                            isFirstNumber = true;
                        }
                        break;
                    default:
                        if (currentInput.length() > 0) {
                            firstNumber = Double.parseDouble(currentInput.toString());
                            currentOperation = operation;
                            currentInput.setLength(0);
                            isFirstNumber = false;
                        }
                        break;
                }
            }
        };

        for (int id : operationButtonIds) {
            findViewById(id).setOnClickListener(operationButtonClickListener);
        }
    }

    private double performOperation(double num1, double num2, String operation) {
        switch (operation) {
            case "÷":
                return num1 / num2;
            case "×":
                return num1 * num2;
            case "-":
                return num1 - num2;
            case "+":
                return num1 + num2;
            default:
                return 0;
        }
    }

    private void setHistoryButtonListener() {
        ImageButton buttonHistory = findViewById(R.id.buttonHistory);
        buttonHistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                StringBuilder historyText = new StringBuilder();
                for (String entry : history) {
                    historyText.append(entry).append("\n");
                }

                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("Calculation History")
                        .setMessage(historyText.toString())
                        .setPositiveButton("Close", null)
                        .show();
            }
        });
    }
}
