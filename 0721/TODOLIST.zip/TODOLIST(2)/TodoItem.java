package com.example.todolist;

import java.util.Date;

public class TodoItem {
    private String task;
    private Date date;
    private boolean isCompleted;

    public TodoItem(String task, Date date, boolean isCompleted) {
        this.task = task;
        this.date = date;
        this.isCompleted = isCompleted;
    }

    public String getTask() {
        return task;
    }

    public void setTask(String task) {
        this.task = task;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public boolean isCompleted() {
        return isCompleted;
    }

    public void setCompleted(boolean completed) {
        isCompleted = completed;
    }
}
