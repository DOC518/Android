package com.example.a0318ex11;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private ImageView imageView;
    private Button rotateButton;
    private EditText angleEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageView = findViewById(R.id.imageView);
        rotateButton = findViewById(R.id.rotateButton);
        angleEditText = findViewById(R.id.angleEditText);

        rotateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rotateImageClockwise();
            }
        });
    }

    private void rotateImageClockwise() {
        String angleStr = angleEditText.getText().toString();

        if (!angleStr.isEmpty()) {
            try {
                float angle = Float.parseFloat(angleStr);
                // 시계 방향으로 회전하도록 수정
                imageView.setRotation(imageView.getRotation() + angle);
            } catch (NumberFormatException e) {
                // 부적절한 형식의 문자열이 입력된 경우 처리할 코드
                Toast.makeText(this, "Invalid angle format", Toast.LENGTH_SHORT).show();
            }
        } else {
            // 빈 문자열이 입력된 경우 처리할 코드
            Toast.makeText(this, "Please enter an angle", Toast.LENGTH_SHORT).show();
        }
    }
}
