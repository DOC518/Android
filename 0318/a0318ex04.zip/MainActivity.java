package com.example.a0318ex04;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.WindowCompat;

public class MainActivity extends AppCompatActivity {

    EditText eText;
    private TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false); // EdgeToEdge.enable(this)를 사용하지 않는 경우
        eText = findViewById(R.id.edittext);
        textView = findViewById(R.id.textView);
    }

    public void onClicked(View v) {
        String str = eText.getText().toString();
        textView.setText(str);
    }
}
