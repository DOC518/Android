package com.example.a0318ex03;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private TextView textviewRandomNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textviewRandomNumber = findViewById(R.id.textViewRandomNumber);
    }

    public void generateRandomNumber(View view){
        Random random = new Random();
        int randomNumber = random.nextInt(101); // 0부터 100까지의 난수 생성

        textviewRandomNumber.setText("난수: " + randomNumber);
    }

}
