package com.example.a0318ex10;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private ImageView dice1ImageView, dice2ImageView;
    private TextView resultTextView;

    private int[] diceImages = {
            R.drawable.dice1,
            R.drawable.dice2,
            R.drawable.dice3,
            R.drawable.dice4,
            R.drawable.dice5,
            R.drawable.dice6
    };

    private int[] diceCounts = new int[6]; // 각 주사위 값의 횟수를 저장할 배열

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dice1ImageView = findViewById(R.id.dice1ImageView);
        dice2ImageView = findViewById(R.id.dice2ImageView);
        resultTextView = findViewById(R.id.resultTextView);
    }

    public void rollDice(View view) {
        Random random = new Random();

        // 첫 번째 주사위 굴리기
        int dice1Value = random.nextInt(6) + 1;
        dice1ImageView.setImageResource(diceImages[dice1Value - 1]);
        diceCounts[dice1Value - 1]++; // 주사위 값 횟수 증가

        // 두 번째 주사위 굴리기
        int dice2Value = random.nextInt(6) + 1;
        dice2ImageView.setImageResource(diceImages[dice2Value - 1]);
        diceCounts[dice2Value - 1]++; // 주사위 값 횟수 증가

        // 통계 업데이트
        updateStatistics();
    }

    private void updateStatistics() {
        StringBuilder result = new StringBuilder();
        result.append("주사위 통계:\n");
        for (int i = 0; i < diceCounts.length; i++) {
            result.append("주사위 ").append(i + 1).append(": ").append(diceCounts[i]).append("번\n");
        }
        resultTextView.setText(result.toString());
    }
}
