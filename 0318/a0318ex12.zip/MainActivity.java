package com.example.a0318ex12;

import java.util.Random;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private EditText guessEditText;
    private Button submitGuessButton;
    private TextView hintTextView;
    private int answer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        guessEditText = findViewById(R.id.guessEditText);
        submitGuessButton = findViewById(R.id.submitGuessButton);
        hintTextView = findViewById(R.id.hintTextView);

        // 랜덤으로 1~100 사이의 정수 생성
        Random random = new Random();
        answer = random.nextInt(100) + 1;

        submitGuessButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkGuess();
            }
        });
    }


    private void checkGuess() {
        // 사용자가 입력한 값을 가져오기
        String guessStr = guessEditText.getText().toString();

        // 입력 값이 비어 있는지 확인
        if (!guessStr.isEmpty()) {
            // 정수로 변환
            int guess = Integer.parseInt(guessStr);

            // 정답과 비교
            if (guess == answer) {
                showToast("축하합니다. 맞추셨습니다.");
            } else if (guess < answer) {
                hintTextView.setText("낮습니다. 더 높은 숫자로 해보세요");
            } else {
                hintTextView.setText("높습니다. 더 낮은 숫자로 해보세요");
            }
        } else {
            showToast("추측 값을 입력해주세요.");
        }
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
