package com.example.a0408ex14;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private RadioGroup rg;
    private ImageView img;
    private int[] imageResources = {R.drawable.image0, R.drawable.image1, R.drawable.image2};
    private int lastCheckedId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rg = findViewById(R.id.radioGroup);
        img = findViewById(R.id.imageView);

        // 라디오 그룹에서 라디오 버튼 선택 시 이미지 변경
        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId != lastCheckedId) {
                    int index = 0;
                    if (checkedId == R.id.btn1) {
                        index = 0;
                    } else if (checkedId == R.id.btn2) {
                        index = 1;
                    } else if (checkedId == R.id.btn3) {
                        index = 2;
                    }
                    img.setImageResource(imageResources[index]);
                    lastCheckedId = checkedId;
                } else {
                    // 체크했던 라디오 버튼을 다시 클릭하여 해제할 경우
                    rg.clearCheck();
                    img.setImageDrawable(null);
                    lastCheckedId = -1;
                }
            }
        });
    }
}
